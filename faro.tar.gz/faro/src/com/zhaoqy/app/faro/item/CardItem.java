package com.zhaoqy.app.faro.item;

import android.os.Parcel;
import android.os.Parcelable;

public class CardItem implements Parcelable 
{
	private String mIcon;
	private String mName;
	private String mValue;
	private String mState;
	private String mValidity;
	
	public CardItem()
	{
	}
	
	public CardItem(CardItem item)
	{
		mIcon = item.mIcon;
		mName = item.mName;
		mValue = item.mValue;
		mState = item.mState;
		mValidity = item.mValidity;
	}
	
	@Override
	public int describeContents() 
	{
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) 
	{
		dest.writeString(mIcon);
		dest.writeString(mName);
		dest.writeString(mValue);
		dest.writeString(mState);
		dest.writeString(mValidity);
	}
	
	public static final Parcelable.Creator<CardItem> CREATOR = new Parcelable.Creator<CardItem>() 
	{
		public CardItem createFromParcel(Parcel in) 
		{
			return new CardItem(in);
		}

		public CardItem[] newArray(int size) 
		{
			return new CardItem[size];
		}
	};

	private CardItem(Parcel in) 
	{
		mIcon = in.readString();
		mName = in.readString();
		mValue = in.readString();
		mState = in.readString();
		mValidity = in.readString();
	}
	
	public String getIcon() 
	{
		return mIcon;
	}
	
	public void setIcon(String icon) 
	{
		mIcon = icon;
	}
	
	public String getName() 
	{
		return mName;
	}
	
	public void setName(String name) 
	{
		mName = name;
	}
	
	public String getValue() 
	{
		return mValue;
	}
	
	public void setValue(String value) 
	{
		mValue = value;
	}
	
	public String getState() 
	{
		return mState;
	}
	
	public void setState(String state) 
	{
		mState = state;
	}
	
	public String getValidity() 
	{
		return mValidity;
	}
	
	public void setValidity(String validity) 
	{
		mValidity = validity;
	}
}
