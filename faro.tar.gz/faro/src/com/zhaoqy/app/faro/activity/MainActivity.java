package com.zhaoqy.app.faro.activity;

import com.zhaoqy.app.faro.R;
import com.zhaoqy.app.faro.fragment.FindFragment;
import com.zhaoqy.app.faro.fragment.PersonalFragment;
import com.zhaoqy.app.faro.fragment.PublishFragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;

import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MainActivity extends FragmentActivity implements OnClickListener, OnPageChangeListener
{
	private ViewPager        mPager;
	private FindFragment     mFindFragment;
	private PublishFragment  mPublishFragment;
	private PersonalFragment mPersonalFragment;
	private RelativeLayout   mFind;
	private RelativeLayout   mPublish;
	private RelativeLayout   mPersonal;
	private ImageView[]      mIcons = new ImageView[3];
	private TextView[]       mNames = new TextView[3];
	private int              mPreIndex;
	private int              mCurIndex;
	
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		initViews();
		setOnListener();
		initFragment();
		initData();
	}
	
	private void initViews() 
	{
		mPager = (ViewPager)findViewById(R.id.id_main_viewpager);
		
		mFind = (RelativeLayout) findViewById(R.id.id_bottom_find);
		mPublish = (RelativeLayout) findViewById(R.id.id_bottom_publish);
		mPersonal = (RelativeLayout) findViewById(R.id.id_bottom_personal);		
		
		mIcons[0] = (ImageView) findViewById(R.id.id_bottom_find_icon);
		mIcons[1] = (ImageView) findViewById(R.id.id_bottom_publish_icon);
		mIcons[2] = (ImageView) findViewById(R.id.id_bottom_personal_icon);
		
		mNames[0] = (TextView) findViewById(R.id.id_bottom_find_name);
		mNames[1] = (TextView) findViewById(R.id.id_bottom_publish_name);
		mNames[2] = (TextView) findViewById(R.id.id_bottom_personal_name);
		
	}
	
	private void setOnListener() 
	{
		mFind.setOnClickListener(this);
		mPublish.setOnClickListener(this);
		mPersonal.setOnClickListener(this);
	}
	
	private void initFragment()
	{
		mPager.setAdapter(new PagerAdapter(getSupportFragmentManager()));
		mPager.setOffscreenPageLimit(2);
		mPager.setCurrentItem(0);
		mPager.setOnPageChangeListener(this);
	}
	
	private void initData() 
	{
		mCurIndex = 0;
		mIcons[mCurIndex].setSelected(true);
		mNames[mCurIndex].setTextColor(0xFF8DB6CD);
	}

	@Override
	public void onClick(View v) 
	{
		switch (v.getId()) 
		{
		case R.id.id_bottom_find:
		{
			mPreIndex = mCurIndex;
			mCurIndex = 0;
			break;
		}
		case R.id.id_bottom_publish:
		{
			mPreIndex = mCurIndex;
			mCurIndex = 1;
			break;
		}
		case R.id.id_bottom_personal:
		{
			mPreIndex = mCurIndex;
			mCurIndex = 2;
			break;
		}
		default:
			break;
		}
		
		mIcons[mPreIndex].setSelected(false);
		mNames[mPreIndex].setTextColor(0xFF808080);
		mIcons[mCurIndex].setSelected(false);
		mNames[mCurIndex].setTextColor(0xFF8DB6CD);
		mPager.setCurrentItem(mCurIndex);
	}
	
	@Override
	public void onPageScrollStateChanged(int arg0) 
	{
	}

	@Override
	public void onPageScrolled(int arg0, float arg1, int arg2) 
	{
	}

	@Override
	public void onPageSelected(int arg0) 
	{
		switch (arg0) 
		{
		case 0:
		{
			mPreIndex = mCurIndex;
			mCurIndex = 0;
			break;
		}
		case 1:
		{
			mPreIndex = mCurIndex;
			mCurIndex = 1;
			break;
		}
		case 2:
		{
			mPreIndex = mCurIndex;
			mCurIndex = 2;
			break;
		}
		default:
			break;
		}
		
		mIcons[mPreIndex].setSelected(false);
		mNames[mPreIndex].setTextColor(0xFF808080);
		mIcons[mCurIndex].setSelected(false);
		mNames[mCurIndex].setTextColor(0xFF8DB6CD);
		mPager.setCurrentItem(mCurIndex);
	}
	
	public class PagerAdapter extends FragmentPagerAdapter
	{
	    public PagerAdapter(FragmentManager fm) 
	    { 
	        super(fm);  
	    }  
		
		@Override
		public Fragment getItem(int position) 
		{
			switch (position)
			{
			case 0:
			{
				mFindFragment = new FindFragment();
				return mFindFragment;
			}
			case 1:
			{
				mPublishFragment = new PublishFragment();
				return mPublishFragment;
			}
			case 2:
			{
				mPersonalFragment = new PersonalFragment();
				return mPersonalFragment;
			}
			default:
				return null;
			}
		}  
	  
	    @Override  
	    public int getCount() 
	    {
	    	return 3; 
	    }
	}
}
