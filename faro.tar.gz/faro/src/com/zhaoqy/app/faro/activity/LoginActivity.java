package com.zhaoqy.app.faro.activity;

import com.zhaoqy.app.faro.R;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class LoginActivity extends Activity implements OnClickListener
{
	private Context   mContext;
	private TextView  mTitle;
	private ImageView mBack;
	private EditText  mEmail;
	private EditText  mPwd;
	private TextView  mForget;
	private Button    mLogin;
	private TextView  mNew;
	private View      mQQ;
	private View      mWeixin;
	private View      mWeibo;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		mContext = this;
		
		initView(); 
		initData();
		setListener();
	}
	
	private void initView() 
	{
		mTitle = (TextView) findViewById(R.id.id_title_text);
		mBack = (ImageView) findViewById(R.id.id_title_left_img);
		mEmail = (EditText) findViewById(R.id.id_login_email);
		mPwd = (EditText) findViewById(R.id.id_login_password);
		mForget = (TextView) findViewById(R.id.id_login_forget);
		mLogin = (Button) findViewById(R.id.id_login_send);
		mNew = (TextView) findViewById(R.id.id_login_new);
		mQQ = findViewById(R.id.id_login_qq);
		mWeixin = findViewById(R.id.id_login_weixin);
		mWeibo = findViewById(R.id.id_login_weibo);
	}

	private void initData() 
	{
		mBack.setVisibility(View.INVISIBLE);
		mTitle.setText("登录");
	}

	private void setListener() 
	{
		mBack.setOnClickListener(this);
		mForget.setOnClickListener(this);
		mLogin.setOnClickListener(this);
		mNew.setOnClickListener(this);
		mQQ.setOnClickListener(this);
		mWeixin.setOnClickListener(this);
		mWeibo.setOnClickListener(this);
		mEmail.addTextChangedListener(new TextChange());
		mPwd.addTextChangedListener(new TextChange());
	}

	@Override
	public void onClick(View v) 
	{
		switch (v.getId()) 
		{
		case R.id.id_title_left_img:
		{
			finish();
			break;
		}
		case R.id.id_login_forget:
		{
			break;
		}
		case R.id.id_login_send:
		{
			Intent intent = new Intent(mContext, MainActivity.class);
			startActivity(intent);
			break;
		}
		case R.id.id_login_new:
		{
			Intent intent = new Intent(mContext, RegisterActivity.class);
			startActivity(intent);
			break;
		}
		case R.id.id_login_qq:
		case R.id.id_login_weixin:
		case R.id.id_login_weibo:
		{
			Intent intent = new Intent(mContext, ThirdActivity.class);
			startActivity(intent);
			break;
		}
		default:
			break;
		}
	}
	
	class TextChange implements TextWatcher 
	{
		@Override
		public void afterTextChanged(Editable arg0) 
		{
		}

		@Override
		public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) 
		{
		}

		@SuppressWarnings("deprecation")
		@Override
		public void onTextChanged(CharSequence cs, int start, int before, int count) 
		{
			boolean email = mEmail.getText().length() > 0;
			boolean pwd = mPwd.getText().length() > 0;
			if (email & pwd) 
			{
				mLogin.setBackgroundDrawable(getResources().getDrawable(R.drawable.button_enable_shape));
				mLogin.setTextColor(0xFF808080);
				mLogin.setEnabled(true);
			}
			else 
			{
				mLogin.setBackgroundDrawable(getResources().getDrawable(R.drawable.button_disable_shape));
				mLogin.setTextColor(0xFF808080);
				mLogin.setEnabled(false);
			}
		}
	}
}
