package com.zhaoqy.app.faro.activity;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.TextView;
import com.zhaoqy.app.faro.R;
import com.zhaoqy.app.faro.adapter.ViewAdapter;

public class MessageActivity extends Activity implements OnClickListener, OnPageChangeListener
{
	private ImageView  mBack;
	private TextView   mTextView1;
	private TextView   mTextView2;
	private ImageView  mImageView;   
	private ViewPager  mViewPager;    
	private View       mView1;       
	private View       mView2;            
	private List<View> mViews;       
	private int        mOffset = 0;   
	private int        mCurIndex = 0; 
	private int        mBmpW;    
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_message);
		
		initView(); 
		InitImageView();
		initViewPager();
		setListener();
	}

	private void initView() 
	{
		mBack = (ImageView) findViewById(R.id.id_message_back);
		mTextView1 = (TextView) findViewById(R.id.id_message_user);
		mTextView2 = (TextView) findViewById(R.id.id_message_system);
		mImageView = (ImageView) findViewById(R.id.id_message_selected);
		mViewPager = (ViewPager) findViewById(R.id.id_message_viewpager);
	}
	
	private void InitImageView() 
	{
		//获取图片宽度  
		mBmpW = BitmapFactory.decodeResource(getResources(), R.drawable.icon_bottom).getWidth(); 
		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		//获取分辨率宽度  
		int screenW = dm.widthPixels;  
		//计算偏移量  
		mOffset = (screenW / 2 - mBmpW) / 2;  
		Matrix matrix = new Matrix();
		matrix.postTranslate(mOffset, 0);
		mImageView.setImageMatrix(matrix);  
	}

	private void initViewPager() 
	{
		mViews = new ArrayList<View>();
		LayoutInflater inflater = getLayoutInflater();
		mView1 = inflater.inflate(R.layout.view_message_user, null);
		mView2 = inflater.inflate(R.layout.view_message_user, null);
		mViews.add(mView1);
		mViews.add(mView2);
		mViewPager.setAdapter(new ViewAdapter(mViews));
		mViewPager.setCurrentItem(0);
		mViewPager.setOnPageChangeListener(this);
	}

	private void setListener() 
	{
		mBack.setOnClickListener(this);
		mTextView1.setOnClickListener(this);
		mTextView2.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) 
	{
		switch (v.getId()) 
		{
		case R.id.id_message_back:
		{
			finish();
			break;
		}
		case R.id.id_message_user:
		{
			mViewPager.setCurrentItem(0);		
			break;
		}
		case R.id.id_message_system:
		{
			mViewPager.setCurrentItem(1);		
			break;
		}
		default:
			break;
		}
	}

	@Override
	public void onPageScrollStateChanged(int arg0) 
	{
	}

	@Override
	public void onPageScrolled(int arg0, float arg1, int arg2) 
	{
	}

	@Override
	public void onPageSelected(int arg0) 
	{
		int one = mOffset * 2 + mBmpW;
		Animation animation = new TranslateAnimation(one*mCurIndex, one*arg0, 0, 0);
		mCurIndex = arg0;
		//True: 图片停在动画结束位置 
		animation.setFillAfter(true);  
		animation.setDuration(300);
		mImageView.startAnimation(animation);
	}
}
