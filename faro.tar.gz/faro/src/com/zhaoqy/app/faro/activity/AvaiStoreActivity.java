package com.zhaoqy.app.faro.activity;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.zhaoqy.app.faro.R;
import com.zhaoqy.app.faro.adapter.StoreAdapter;
import com.zhaoqy.app.faro.item.StoreItem;

public class AvaiStoreActivity extends Activity implements OnClickListener
{
	private Context         mContext;
	private TextView        mTitle;
	private ImageView       mBack;
	private ListView        mListView;
	private StoreAdapter    mAdapter;
	private List<StoreItem> mList;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_avaistore);
		mContext = this;
		
		initView(); 
		initData();
		setListener();
	}

	private void initView() 
	{
		mTitle = (TextView) findViewById(R.id.id_title_text);
		mBack = (ImageView) findViewById(R.id.id_title_left_img);
		mListView = (ListView) findViewById(R.id.id_avaistore_listview);
	}

	private void initData() 
	{
		mTitle.setText("可用门店");
		mList = getStoreList();
		mAdapter = new StoreAdapter(mContext, mList);
		mListView.setAdapter(mAdapter);
	}

	private void setListener() 
	{
		mBack.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) 
	{
		switch (v.getId()) 
		{
		case R.id.id_title_left_img:
		{
			finish();
			break;
		}
		default:
			break;
		}
	}
	
	private List<StoreItem> getStoreList() 
	{
		List<StoreItem> storeList = new ArrayList<StoreItem>();
		StoreItem item0 = new StoreItem();
		item0.setName("深圳市南山区蛇口工业六路36号");
		storeList.add(item0);
		
		StoreItem item1 = new StoreItem();
		item1.setName("深圳市南山区蛇口工业六路42号");
		storeList.add(item1);
		
		StoreItem item2 = new StoreItem();
		item2.setName("深圳市南山区蛇口工业六路43号");
		storeList.add(item2);
		
		StoreItem item3 = new StoreItem();
		item3.setName("深圳市南山区蛇口工业六路17号");
		storeList.add(item3);
		
		StoreItem item4 = new StoreItem();
		item4.setName("深圳市南山区蛇口工业六路34号");
		storeList.add(item4);
		
		StoreItem item5 = new StoreItem();
		item5.setName("深圳市南山区蛇口工业六路14号");
		storeList.add(item5);
		
		return storeList;
	}
}
