package com.zhaoqy.app.faro.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.zhaoqy.app.faro.R;

public class OfferActivity extends Activity implements OnClickListener
{
	private Context      mContext;
	private TextView     mTitle;
	private ImageView    mBack;
	private LinearLayout mStore;
	//RecyclerView m;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_offer_detail);
		mContext = this;
		
		initView(); 
		initData();
		setListener();
	}

	private void initView() 
	{
		mTitle = (TextView) findViewById(R.id.id_title_text);
		mBack = (ImageView) findViewById(R.id.id_title_left_img);
		mStore = (LinearLayout) findViewById(R.id.id_offer_avaistore);
	}

	private void initData() 
	{
		mTitle.setText("优惠详情");
	}

	private void setListener() 
	{
		mBack.setOnClickListener(this);
		mStore.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) 
	{
		switch (v.getId()) 
		{
		case R.id.id_title_left_img:
		{
			finish();
			break;
		}
		case R.id.id_offer_avaistore:
		{
			Intent intent = new Intent(mContext, AvaiStoreActivity.class);
			startActivity(intent);
			break;
		}
		default:
			break;
		}
	}
}
