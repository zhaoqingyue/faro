package com.zhaoqy.app.faro.activity;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import com.zhaoqy.app.faro.R;
import com.zhaoqy.app.faro.adapter.CardAdapter;
import com.zhaoqy.app.faro.item.CardItem;

public class CardActivity extends Activity implements OnClickListener, OnItemClickListener
{
	private Context        mContext;
	private TextView       mTitle;
	private ImageView      mBack;
	private ListView       mListView;
	private CardAdapter    mAdapter;
	private List<CardItem> mList;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_card);
		mContext = this;
		
		initView(); 
		initData();
		setListener();
	}

	private void initView() 
	{
		mTitle = (TextView) findViewById(R.id.id_title_text);
		mBack = (ImageView) findViewById(R.id.id_title_left_img);
		mListView = (ListView) findViewById(R.id.id_card_listview);
	}

	private void initData() 
	{
		mTitle.setText("我的卡卷");
		mList = getCardList();
		mAdapter = new CardAdapter(mContext, mList);
		mListView.setAdapter(mAdapter);
	}

	private void setListener() 
	{
		mBack.setOnClickListener(this);
		mListView.setOnItemClickListener(this);
	}

	@Override
	public void onClick(View v) 
	{
		switch (v.getId()) 
		{
		case R.id.id_title_left_img:
		{
			finish();
			break;
		}
		default:
			break;
		}
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) 
	{
		Intent intent = new Intent(mContext, OfferActivity.class);
		startActivity(intent);
	}
	
	private List<CardItem> getCardList()
	{
		List<CardItem> cardList = new ArrayList<CardItem>();
		CardItem item0 = new CardItem();
		
		item0.setIcon("");
		item0.setName("NIKE");
		item0.setValue("50元");
		item0.setValidity("2016-01-21 12:00");
		item0.setState("未使用");
		cardList.add(item0);
		
		CardItem item1 = new CardItem();
		item1.setIcon("");
		item1.setName("ADIDAS");
		item1.setValue("100元");
		item1.setValidity("2015-11-21 14:25");
		item1.setState("已使用");
		cardList.add(item1);
		
		CardItem item2 = new CardItem();
		item2.setIcon("");
		item2.setName("ADIDAS");
		item2.setValue("100元");
		item2.setValidity("2015-11-21 14:25");
		item2.setState("已使用");
		cardList.add(item2);
		
		CardItem item3 = new CardItem();
		item3.setIcon("");
		item3.setName("ADIDAS");
		item3.setValue("100元");
		item3.setValidity("2015-11-21 14:25");
		item3.setState("已使用");
		cardList.add(item3);
		
		CardItem item4 = new CardItem();
		item4.setIcon("");
		item4.setName("ADIDAS");
		item4.setValue("100元");
		item4.setValidity("2015-11-21 14:25");
		item4.setState("已使用");
		cardList.add(item4);
		
		return cardList;
	}
}
