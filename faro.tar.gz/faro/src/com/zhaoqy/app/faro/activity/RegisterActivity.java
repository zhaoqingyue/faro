package com.zhaoqy.app.faro.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.zhaoqy.app.faro.R;

public class RegisterActivity extends Activity implements OnClickListener
{
	private Context      mContext;
	private TextView     mTitle;
	private ImageView    mBack;
	private LinearLayout mAccount;
	private EditText     mEmail;
	private EditText     mPwd;
	private Button       mRegister;
	private TextView     mProtocol;
	private LinearLayout mSecurity;
	private EditText     mSecurityCode;
	private TextView     mTime;
	private TextView     mResend;
	private Button       mFinish;
	private int          mSecond;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_register);
		mContext = this;
		
		initView(); 
		initData();
		setListener();
	}

	private void initView() 
	{
		mTitle = (TextView) findViewById(R.id.id_title_text);
		mBack = (ImageView) findViewById(R.id.id_title_left_img);
		mAccount = (LinearLayout) findViewById(R.id.id_register_account);
		mEmail = (EditText) findViewById(R.id.id_register_email);
		mPwd = (EditText) findViewById(R.id.id_register_password);
		mRegister = (Button) findViewById(R.id.id_register_send);
		mProtocol = (TextView) findViewById(R.id.id_register_protocol);
		mSecurity = (LinearLayout) findViewById(R.id.id_register_security);
		mSecurityCode  = (EditText) findViewById(R.id.id_register_security_code);
		mTime = (TextView) findViewById(R.id.id_register_security_time);
		mResend = (TextView) findViewById(R.id.id_register_security_resend);
		mFinish = (Button) findViewById(R.id.id_register_security_finish);
	}

	private void initData() 
	{
		mTitle.setText("注册");
	}

	private void setListener() 
	{
		mBack.setOnClickListener(this);
		mRegister.setOnClickListener(this);
		mProtocol.setOnClickListener(this);
		mResend.setOnClickListener(this);
		mFinish.setOnClickListener(this);
		mEmail.addTextChangedListener(new AccountChange());
		mPwd.addTextChangedListener(new AccountChange());
		mSecurityCode.addTextChangedListener(new SecurityChange());
	}

	@Override
	public void onClick(View v) 
	{
		switch (v.getId()) 
		{
		case R.id.id_title_left_img:
		{
			finish();
			break;
		}
		case R.id.id_register_send:
		{
			mAccount.setVisibility(View.GONE);
			mSecurity.setVisibility(View.VISIBLE);
			mSecond = 60;
			mTime.setText(mSecond + "s");
			mHandler.sendEmptyMessageDelayed(0, 1000);
			break;
		}
		case R.id.id_register_protocol:
		{
			Intent intent = new Intent(mContext, ProtocolActivity.class);
			startActivity(intent);
			break;
		}
		case R.id.id_register_security_resend:
		{
			mTime.setVisibility(View.VISIBLE);
			mResend.setVisibility(View.GONE);
			mSecond = 60;
			mTime.setText(mSecond + "s");
			mHandler.sendEmptyMessageDelayed(0, 1000);
			break;
		}
		case R.id.id_register_security_finish:
		{
			finish();
			break;
		}
		default:
			break;
		}
	}
	
	class AccountChange implements TextWatcher 
	{
		@Override
		public void afterTextChanged(Editable arg0) 
		{
		}

		@Override
		public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) 
		{
		}

		@SuppressWarnings("deprecation")
		@Override
		public void onTextChanged(CharSequence cs, int start, int before, int count) 
		{
			boolean email = mEmail.getText().length() > 0;
			boolean pwd = mPwd.getText().length() > 0;
			if (email & pwd) 
			{
				mRegister.setBackgroundDrawable(getResources().getDrawable(R.drawable.button_enable_shape));
				mRegister.setTextColor(0xFF808080);
				mRegister.setEnabled(true);
			}
			else 
			{
				mRegister.setBackgroundDrawable(getResources().getDrawable(R.drawable.button_disable_shape));
				mRegister.setTextColor(0xFF808080);
				mRegister.setEnabled(false);
			}
		}
	}
	
	class SecurityChange implements TextWatcher 
	{
		@Override
		public void afterTextChanged(Editable arg0) 
		{
		}

		@Override
		public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) 
		{
		}

		@SuppressWarnings("deprecation")
		@Override
		public void onTextChanged(CharSequence cs, int start, int before, int count) 
		{
			boolean code = mSecurityCode.getText().length() > 0;
			if (code) 
			{
				mFinish.setBackgroundDrawable(getResources().getDrawable(R.drawable.button_enable_shape));
				mFinish.setTextColor(0xFF808080);
				mFinish.setEnabled(true);
			}
			else 
			{
				mFinish.setBackgroundDrawable(getResources().getDrawable(R.drawable.button_disable_shape));
				mFinish.setTextColor(0xFF808080);
				mFinish.setEnabled(false);
			}
		}
	}
	
	@SuppressLint("HandlerLeak")
	private Handler mHandler = new Handler()
	{
		public void handleMessage(Message msg)
		{
			if (mSecond > 0)
			{
				mSecond--;
				mTime.setText(mSecond + "s");
				mHandler.sendEmptyMessageDelayed(0, 1000);
			}
			else
			{
				mTime.setVisibility(View.GONE);
				mResend.setVisibility(View.VISIBLE);
			}
		}
	};
}
