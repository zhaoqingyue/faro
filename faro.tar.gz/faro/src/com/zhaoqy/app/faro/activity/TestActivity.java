package com.zhaoqy.app.faro.activity;

import java.util.Calendar;

import com.zhaoqy.app.faro.R;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.TimePicker;

public class TestActivity extends Activity implements OnClickListener
{
	private TextView  mTitle;
	private ImageView mBack;
	
	private DatePicker datePicker;
	private Calendar calendar;
	private int year;
	private int month;
	private int day;
	private TextView  text1;
	
	private TimePicker timePicker;
	private int hour;
	private int minute;
	private TextView  text2;
	
	
	private NumberPicker numberPicker;
	private TextView currentNumShow;

	private int minNum = 1, maxNum = 20, currentNum = 10;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_test);
		
		initView(); 
		initData();
		setListener();
		
		initDatePicker();
		initTimePicker();
		initNumberPicker();
	}

	private void initView() 
	{
		mTitle = (TextView) findViewById(R.id.id_title_text);
		mBack = (ImageView) findViewById(R.id.id_title_left_img);
		
		datePicker = (DatePicker) findViewById(R.id.myDatePicker);
		text1  = (TextView) findViewById(R.id.myDatePicker_text);
		
		timePicker = (TimePicker) findViewById(R.id.myTimePicker);
		text2  = (TextView) findViewById(R.id.myTimePicker_text);
		
		numberPicker = (NumberPicker) findViewById(R.id.numberPicker);
		currentNumShow = (TextView) findViewById(R.id.currentNumShow);
	}

	private void initData() 
	{
		mTitle.setText("测试");
		// 获取日历对象
		calendar = Calendar.getInstance();
	}
	
	private void initDatePicker() 
	{
		// 获取当前对应的年、月、日的信息
		year = calendar.get(Calendar.YEAR);
		month = calendar.get(Calendar.MONTH);
		day = calendar.get(Calendar.DAY_OF_MONTH);

		// dataPicker初始化
		datePicker.init(year, month, day, new DatePicker.OnDateChangedListener() 
		{
			@Override
			public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) 
			{
				text1.setText(year + "-" + (monthOfYear + 1) + "-" + dayOfMonth);
			}
		});
		
		// 初始化DatePickerDialog
		new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
		    @Override
		    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
		        setTitle(year + "-" + (monthOfYear + 1) + "-" + dayOfMonth);
		    }
		}, year, month, day).show();
	}
	
	private void initTimePicker() 
	{
		// 获取对应的时、分的信息
		hour = calendar.get(Calendar.HOUR_OF_DAY);
		minute = calendar.get(Calendar.MINUTE);
		
		// 为TimePicker指定监听器
		timePicker.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() 
		{
		    @Override
		    public void onTimeChanged(TimePicker view, int hourOfDay, int minute) 
		    {
		    	text2.setText(hourOfDay + "-" + minute);
		    }
		});
		
		// 初始化TimerPickerDialog
		new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
		    @Override
		    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
		        setTitle(hourOfDay + ":" + minute);
		    }
		}, hour, minute, true).show();
		
	}
	
	@SuppressLint("NewApi")
	private void initNumberPicker() 
	{
		// 设置NumberPicker属性
		numberPicker.setMinValue(minNum);
		numberPicker.setMaxValue(maxNum);
		numberPicker.setValue(currentNum);
		
		// 监听数值改变事件
		numberPicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() 
		{
		    @Override
		    public void onValueChange(NumberPicker picker, int oldVal, int newVal) 
		    {
		        currentNum = newVal;
		        // 在TextView中更新数据
		        showCurrentNum();
		    }
		});
	}
	
	// 更新显示当前值的TextView
	private void showCurrentNum() 
	{
		currentNumShow.setText("Current Number is " + currentNum + ".");
	}

	private void setListener() 
	{
		mBack.setOnClickListener(this);
		
		
	}

	@Override
	public void onClick(View v) 
	{
		switch (v.getId()) 
		{
		case R.id.id_title_left_img:
		{
			finish();
			break;
		}
		default:
			break;
		}
	}
}
