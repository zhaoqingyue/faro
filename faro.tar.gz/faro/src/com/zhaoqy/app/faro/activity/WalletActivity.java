package com.zhaoqy.app.faro.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import com.zhaoqy.app.faro.R;

public class WalletActivity extends Activity implements OnClickListener
{
	private Context   mContext;
	private TextView  mTitle;
	private ImageView mBack;
	private TextView  mScan;   
	private TextView  mCurrency;   
	private TextView  mCard;   
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_wallet);
		mContext = this;
		
		initView(); 
		initData();
		setListener();
	}

	private void initView() 
	{
		mTitle = (TextView) findViewById(R.id.id_title_text);
		mBack = (ImageView) findViewById(R.id.id_title_left_img);
		mScan = (TextView) findViewById(R.id.id_wallet_scan);
		mCurrency = (TextView) findViewById(R.id.id_wallet_currency);
		mCard = (TextView) findViewById(R.id.id_wallet_card);
	}

	private void initData() 
	{
		mTitle.setText("我的钱包");
	}

	private void setListener() 
	{
		mBack.setOnClickListener(this);
		mScan.setOnClickListener(this);
		mCurrency.setOnClickListener(this);
		mCard.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) 
	{
		switch (v.getId()) 
		{
		case R.id.id_title_left_img:
		{
			finish();
			break;
		}
		case R.id.id_wallet_scan:
		{
			break;
		}
		case R.id.id_wallet_currency:
		{
			break;
		}
		case R.id.id_wallet_card:
		{
			Intent intent = new Intent(mContext, CardActivity.class);
			startActivity(intent);
			break;
		}
		default:
			break;
		}
	}
}
