package com.zhaoqy.app.faro.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.TextView;
import com.zhaoqy.app.faro.R;
import com.zhaoqy.app.faro.activity.EditActivity;
import com.zhaoqy.app.faro.activity.WebViewActivity;

public class PublishFragment extends Fragment implements OnClickListener
{
	private TextView test;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) 
	{
		View view = inflater.inflate(R.layout.fragment_publish, container, false);
		
		test  = (TextView) view.findViewById(R.id.txt_nochat);  
		test.setOnClickListener(this);
		return view;
	}

	@Override
	public void onClick(View v) 
	{
		/*Intent intent = new Intent();
		intent.setClass(getActivity(), WebViewActivity.class);
		intent.putExtra("Title", "百度");
		intent.putExtra("URL", "https://m.baidu.com");
		startActivity(intent);*/
		
		Intent intent = new Intent();
		intent.setClass(getActivity(), EditActivity.class);
		startActivity(intent);
	}
}
