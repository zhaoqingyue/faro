package com.zhaoqy.app.faro.adapter;

import java.util.List;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.zhaoqy.app.faro.R;
import com.zhaoqy.app.faro.item.StoreItem;

public class StoreAdapter extends BaseAdapter 
{
	private Context         mContext;
	private List<StoreItem> mList;
	
	public StoreAdapter(Context context, List<StoreItem> list) 
	{
		super();
		mContext = context;
		mList = list;
	}
	
	@Override
	public int getCount() 
	{
		if(mList != null)
		{
			return mList.size();
		}
		return 0;
	}

	@Override
	public Object getItem(int position) 
	{
		return mList.get(position);
	}

	@Override
	public long getItemId(int position) 
	{
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) 
	{
		ViewHolder mHolder = null;
		if(convertView == null)
		{
			convertView = LayoutInflater.from(mContext).inflate(R.layout.item_avaistore, null);
			mHolder = new ViewHolder();
			mHolder.mName = (TextView) convertView.findViewById(R.id.id_avaistore_name);
			convertView.setTag(mHolder);
		}
		else
		{
			mHolder = (ViewHolder) convertView.getTag();
		}
		
		mHolder.mName.setText(mList.get(position).getName());
		return convertView;
	}
	
	static class ViewHolder 
	{
        TextView  mName; 
    }
}
