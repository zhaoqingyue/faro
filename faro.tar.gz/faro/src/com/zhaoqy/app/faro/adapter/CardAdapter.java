package com.zhaoqy.app.faro.adapter;

import java.util.List;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.zhaoqy.app.faro.R;
import com.zhaoqy.app.faro.item.CardItem;

public class CardAdapter extends BaseAdapter 
{
	private Context        mContext;
	private List<CardItem> mList;
	
	public CardAdapter(Context context, List<CardItem> list) 
	{
		super();
		mContext = context;
		mList = list;
	}
	
	@Override
	public int getCount() 
	{
		if(mList != null)
		{
			return mList.size();
		}
		return 0;
	}

	@Override
	public Object getItem(int position) 
	{
		return mList.get(position);
	}

	@Override
	public long getItemId(int position) 
	{
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) 
	{
		ViewHolder mHolder = null;
		if(convertView == null)
		{
			convertView = LayoutInflater.from(mContext).inflate(R.layout.item_card, null);
			mHolder = new ViewHolder();
			mHolder.mIcon = (ImageView) convertView.findViewById(R.id.id_card_icon);
			mHolder.mName = (TextView) convertView.findViewById(R.id.id_card_name);
			mHolder.mValue = (TextView) convertView.findViewById(R.id.id_card_value);
			mHolder.mState = (TextView) convertView.findViewById(R.id.id_card_state);
			mHolder.mValidity = (TextView) convertView.findViewById(R.id.id_card_validity);
			convertView.setTag(mHolder);
		}
		else
		{
			mHolder = (ViewHolder) convertView.getTag();
		}
		
		mHolder.mName.setText(mList.get(position).getName());
		mHolder.mValue.setText(mList.get(position).getValue());
		mHolder.mState.setText(mList.get(position).getState());
		mHolder.mValidity.setText(mList.get(position).getValidity());
		return convertView;
	}
	
	static class ViewHolder 
	{
		ImageView mIcon;
        TextView  mName; 
        TextView  mValue; 
        TextView  mState;
        TextView  mValidity; 
    }
}
